# Candy Blast — Android Studio Project

This project wraps the supplied `index.html` Candy Blast game in an Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone with USB debugging enabled, or use an emulator.
4. Press Run to test.
5. For an APK: Build > Generate App Bundles or APKs > Generate APKs.

The debug APK is normally created at:
`app/build/outputs/apk/debug/app-debug.apk`

## Source
The original game file from `Candy_Blast.zip` is included at:
`app/src/main/assets/index.html`
