# Candy Blast - no custom ProGuard rules required.
